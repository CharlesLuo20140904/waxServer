waxClass{"AboutUsViewController", UIViewController}
function viewDidLoad(self)
self:versionLB():setText("Version v2.1.7");
self:companyLB():setText("深圳银米科技有限公司版权所有");
self:linkLB():setText("Copyright  2018  coffeeapi.zhidian668.com");
end