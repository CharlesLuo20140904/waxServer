waxClass{"AboutUsViewController", UIViewController}
function viewDidLoad(self)
self:versionLB():setText("Version v1.1.6");
self:companyLB():setText("深圳银米科技有限公司版权所有");
self:linkLB():setText("Copyright  2018  coffee.zhidian668.com");
end